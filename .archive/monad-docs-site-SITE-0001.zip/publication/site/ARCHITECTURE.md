# Monad Publication Site Architecture

**Work packet:** SITE-0001 of 12  
**Status:** Foundation  
**Application root:** `publication/site/`

## Decision

Use Next.js 16, React 19, Fumadocs Core/UI/MDX, Tailwind CSS 4, TypeScript, and Bun.

## Architectural boundary

The publication application renders and indexes canonical Monad documents, but it does not own them. The canonical corpus remains in the repository's domain-oriented directories, including `journal/`, `architecture/`, `adrs/`, `specifications/`, `engineering/`, `research/`, `knowledge/`, and `build-log/`.

Bootstrap MDX under `content/system/` exists only to keep the site independently runnable before the repository ingestion adapter is implemented in SITE-0003.

## Initial route contract

| Route | Purpose | State |
|---|---|---|
| `/` | Publication landing page | Implemented |
| `/system` | Stable system-reference path | Implemented |
| `/api/search` | Fumadocs search endpoint | Implemented |
| `/building-monad` | Chronological engineering narrative | Reserved |
| `/artifacts` | Specifications, ADRs, research, and records | Reserved |
| `/project` | Status, roadmap, releases, and build log | Reserved |

## Non-goals for SITE-0001

- Importing the external canonical corpus
- Final visual identity
- Artifact relationship graphs
- Versioned publication editions
- PDF, EPUB, RSS, `llms.txt`, or offline outputs
- Production deployment configuration

## Next implementation packet

SITE-0002 will harden the application foundation: shared configuration, route groups, error states, testing baseline, developer tooling, and the first reusable Monad UI primitives.
