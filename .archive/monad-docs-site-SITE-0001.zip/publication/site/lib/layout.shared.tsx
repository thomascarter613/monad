import type { BaseLayoutProps } from 'fumadocs-ui/layouts/shared';

export function baseOptions(): BaseLayoutProps {
  return {
    nav: {
      title: (
        <span className="flex items-baseline gap-2">
          <span className="font-semibold">Monad</span>
          <span className="hidden font-mono text-xs text-fd-muted-foreground sm:inline">
            Engineering Log
          </span>
        </span>
      ),
    },
    links: [
      {
        text: 'System',
        url: '/system',
        active: 'nested-url',
      },
    ],
  };
}
