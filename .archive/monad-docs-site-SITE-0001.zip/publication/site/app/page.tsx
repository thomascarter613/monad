import Link from 'next/link';

const sections = [
  {
    href: '/system',
    eyebrow: 'Reference path',
    title: 'Understand Monad',
    description:
      'Explore the system model, architecture, components, constraints, and technical vocabulary.',
  },
  {
    href: '/system/publication-architecture',
    eyebrow: 'Implementation record',
    title: 'Publication architecture',
    description:
      'See how canonical repository documents become routes, search data, and future derived editions.',
  },
];

export default function HomePage() {
  return (
    <main className="mx-auto flex w-full max-w-[var(--monad-content-max)] flex-1 flex-col px-6 py-16 lg:px-10 lg:py-24">
      <div className="max-w-4xl">
        <p className="mb-5 font-mono text-sm tracking-[0.18em] text-fd-muted-foreground uppercase">
          Monad Engineering Log
        </p>
        <h1 className="text-balance text-5xl font-semibold tracking-[-0.04em] sm:text-7xl">
          Building Monad in public, with the reasoning intact.
        </h1>
        <p className="mt-7 max-w-3xl text-pretty text-lg leading-8 text-fd-muted-foreground sm:text-xl">
          A durable technical publication for Monad&apos;s engineering journal,
          architecture, specifications, decisions, experiments, and implementation history.
        </p>
      </div>

      <div className="mt-14 grid gap-5 md:grid-cols-2">
        {sections.map((section) => (
          <Link
            key={section.href}
            href={section.href}
            className="group rounded-2xl border bg-fd-card p-7 transition hover:-translate-y-0.5 hover:border-fd-primary/50 hover:shadow-lg"
          >
            <p className="font-mono text-xs tracking-[0.16em] text-fd-muted-foreground uppercase">
              {section.eyebrow}
            </p>
            <h2 className="mt-3 text-2xl font-semibold tracking-tight group-hover:text-fd-primary">
              {section.title}
            </h2>
            <p className="mt-3 leading-7 text-fd-muted-foreground">
              {section.description}
            </p>
          </Link>
        ))}
      </div>

      <footer className="mt-auto pt-20 text-sm text-fd-muted-foreground">
        SITE-0001 · Documentation foundation
      </footer>
    </main>
  );
}
