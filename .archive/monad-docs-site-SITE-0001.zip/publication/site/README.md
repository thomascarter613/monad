# Monad Publication Site

Fumadocs-powered documentation and engineering-log publication application for Monad.

## Requirements

- Node.js 20.9 or newer
- Bun

## Local development

```bash
bun install
bun run dev
```

Open `http://localhost:3000`.

## Verification

```bash
bun run typecheck
bun run build
```

## Content boundary

The MDX files under `content/system/` are bootstrap fixtures. Canonical Monad documents remain outside this application and will be consumed through the SITE-0003 ingestion adapter.

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for the current route and ownership decisions.
