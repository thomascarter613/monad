/**
 * Canonical Monad content sources.
 *
 * Paths are relative to the repository root, never the publication site.
 * The generated collection and prefix control only the disposable Fumadocs
 * projection under publication/site/.generated/content.
 */
export const publicationContentSources = Object.freeze([
  Object.freeze({
    key: 'building-monad',
    title: 'Building Monad',
    description:
      'The chronological engineering narrative documenting how Monad is designed and built.',
    kind: 'journal-entry',
    canonicalRoots: ['journal'],
    generatedCollection: 'building-monad',
    generatedPrefix: '',
    routeBase: '/building-monad',
    idRequired: false,
    order: 10,
  }),
  Object.freeze({
    key: 'architecture',
    title: 'Architecture',
    description:
      'Architecture descriptions, models, principles, boundaries, and system views.',
    kind: 'architecture',
    canonicalRoots: ['architecture'],
    generatedCollection: 'system',
    generatedPrefix: 'architecture',
    routeBase: '/system/architecture',
    idRequired: false,
    order: 20,
  }),
  Object.freeze({
    key: 'decisions',
    title: 'Architecture Decisions',
    description:
      'Durable architectural and engineering decisions recorded as ADRs.',
    kind: 'decision',
    canonicalRoots: ['adrs', 'engineering/adrs'],
    generatedCollection: 'artifacts',
    generatedPrefix: 'decisions',
    routeBase: '/artifacts/decisions',
    idRequired: true,
    order: 30,
  }),
  Object.freeze({
    key: 'specifications',
    title: 'Specifications',
    description:
      'Normative specifications that define Monad capabilities, contracts, and behavior.',
    kind: 'specification',
    canonicalRoots: ['specifications'],
    generatedCollection: 'artifacts',
    generatedPrefix: 'specifications',
    routeBase: '/artifacts/specifications',
    idRequired: true,
    order: 40,
  }),
  Object.freeze({
    key: 'engineering',
    title: 'Engineering Records',
    description:
      'Implementation plans, verification records, experiments, and engineering notes.',
    kind: 'engineering',
    canonicalRoots: ['engineering'],
    excludedCanonicalPrefixes: ['engineering/adrs'],
    generatedCollection: 'artifacts',
    generatedPrefix: 'engineering',
    routeBase: '/artifacts/engineering',
    idRequired: false,
    order: 50,
  }),
  Object.freeze({
    key: 'research',
    title: 'Research',
    description:
      'Research notes, comparisons, evidence, and explorations that inform Monad.',
    kind: 'research',
    canonicalRoots: ['research'],
    generatedCollection: 'artifacts',
    generatedPrefix: 'research',
    routeBase: '/artifacts/research',
    idRequired: false,
    order: 60,
  }),
  Object.freeze({
    key: 'knowledge',
    title: 'Knowledge Records',
    description:
      'Curated knowledge records and durable explanatory material used by Monad.',
    kind: 'knowledge',
    canonicalRoots: ['knowledge'],
    generatedCollection: 'artifacts',
    generatedPrefix: 'knowledge',
    routeBase: '/artifacts/knowledge',
    idRequired: false,
    order: 70,
  }),
  Object.freeze({
    key: 'build-log',
    title: 'Build Log',
    description:
      'Operational implementation notes and repository milestones recorded while Monad is built.',
    kind: 'build-log',
    canonicalRoots: ['build-log'],
    generatedCollection: 'project',
    generatedPrefix: 'build-log',
    routeBase: '/project/build-log',
    idRequired: false,
    order: 80,
  }),
]);

export const contentIngestionConfig = Object.freeze({
  schemaVersion: 2,
  acceptedExtensions: ['.md', '.mdx'],
  ignoredDirectoryNames: [
    '.git',
    '.monad',
    '.next',
    '.source',
    'node_modules',
    'target',
    'dist',
    'build',
    'out',
  ],
  ignoredFileNames: ['.DS_Store'],
  maximumDocumentBytes: 2_000_000,
});
