def generate()->str:
    return r"""_ca_complete()
{
    COMPREPLY=()
}
complete -F _ca_complete ca
"""
