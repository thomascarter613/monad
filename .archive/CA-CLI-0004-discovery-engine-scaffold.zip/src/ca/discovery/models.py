from dataclasses import dataclass

@dataclass(frozen=True)
class CompletionItem:
    value:str
    category:str
    description:str=""
