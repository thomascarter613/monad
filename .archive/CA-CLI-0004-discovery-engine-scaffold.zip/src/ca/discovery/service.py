from pathlib import Path
from ca.publishing.manifest import PublicationManifest
from ca.discovery.models import CompletionItem

class DiscoveryService:
    def __init__(self, repo:Path):
        self.repo=repo

    def publications(self)->list[CompletionItem]:
        manifest=PublicationManifest.load(
            self.repo/"publishing"/"publications.yaml"
        )
        items=[]
        for t in manifest.targets():
            items.append(
                CompletionItem(
                    value=t.name,
                    category=t.kind,
                    description=t.description,
                )
            )
        return sorted(items,key=lambda x:(x.category,x.value))
