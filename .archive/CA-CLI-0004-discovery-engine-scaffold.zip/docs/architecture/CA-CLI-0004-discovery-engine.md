# CA-CLI-0004 — Discovery & Completion Engine

Status: Production Draft

## Purpose

Introduce a repository discovery layer that provides a single source of truth
for shell completion, future TUI menus, interactive prompts, and IDE support.

## Discovery providers

- Publications (assemblies/groups)
- Students
- Curriculum
- Standards
- Plugins

Each provider implements a common interface returning structured completion
items instead of shell-specific text.

Shell generators (Bash/Zsh/Fish/PowerShell) consume the same discovery API.
