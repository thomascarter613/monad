from pathlib import Path
from ca.discovery.service import DiscoveryService

def test_import():
    assert DiscoveryService
