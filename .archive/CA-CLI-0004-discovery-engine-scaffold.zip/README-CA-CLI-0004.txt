CA-CLI-0004 scaffold

This milestone establishes the discovery abstraction that future shell
completion, TUI navigation, and interactive workflows will share.
