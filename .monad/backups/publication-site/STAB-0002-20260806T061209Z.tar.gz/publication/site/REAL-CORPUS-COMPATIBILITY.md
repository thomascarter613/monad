# STAB-0001 — Real Corpus Compatibility

SITE-0012 was first exercised against Monad's complete canonical corpus on
2026-08-05. That run exposed three assumptions in the bootstrap ingestion
adapter that did not match the repository's established document conventions.

## Corrections

1. ADRs stored beneath `engineering/adrs/` are classified as decisions and are
   excluded from the general engineering-record source.
2. The frontmatter reader accepts Monad's established grouped, flat metadata
   form, including unindented lists and long hyphen closing delimiters.
3. Index-like files such as `README.md` and `AGENTS.md` no longer acquire their
   identity from the first governed identifier enumerated in their body.

The adapter preserves canonical source files. No mass frontmatter rewrite is
required to build the publication.

## Remaining warnings

Empty placeholder documents, untracked supporting files, and intentional series
position gaps remain warnings. They do not block `bun run build`. They remain
visible so the corpus can be improved intentionally rather than silently.
