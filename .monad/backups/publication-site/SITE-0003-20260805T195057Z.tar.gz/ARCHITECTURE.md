# Monad Publication Site Architecture

**Work packet:** SITE-0002 of 12  
**Status:** Application foundation  
**Application root:** `publication/site/`

## Decision

Use Next.js 16, React 19, Fumadocs Core/UI/MDX, Tailwind CSS 4, TypeScript, Bun, Biome, Vitest, and Playwright.

## Architectural boundary

The publication application renders and indexes canonical Monad documents, but it does not own them. The canonical corpus remains in the repository's domain-oriented directories, including `journal/`, `architecture/`, `adrs/`, `specifications/`, `engineering/`, `research/`, `knowledge/`, and `build-log/`.

Bootstrap MDX under `content/system/` exists only to keep the site independently runnable before the repository ingestion adapter is implemented in SITE-0003.

## Application boundaries

```text
app/
├── (publication)/       # landing and editorial publication surfaces
├── (reference)/         # Fumadocs-backed reference routes
├── api/                 # machine-facing route handlers
├── error.tsx            # recoverable root-segment boundary
├── global-error.tsx     # root-layout failure boundary
├── loading.tsx          # accessible global loading state
└── not-found.tsx        # controlled global 404
```

Route groups organize implementation without changing public URLs.

## Typed contracts

- `lib/config/site.ts` owns stable publication identity.
- `lib/environment.ts` validates deploy-time public URLs.
- `lib/routes.ts` owns active and reserved public paths.
- Reserved paths are visible as information architecture but remain unlinked until implemented.

## Initial route contract

| Route | Purpose | State |
|---|---|---|
| `/` | Publication landing page | Implemented |
| `/system` | Stable system-reference path | Implemented |
| `/api/search` | Fumadocs search endpoint | Implemented |
| `/building-monad` | Chronological engineering narrative | Reserved |
| `/artifacts` | Specifications, ADRs, research, and records | Reserved |
| `/project` | Status, roadmap, releases, and build log | Reserved |

## Quality gate

`bun run verify` is the minimum required check. It performs Biome checks, TypeScript validation, unit tests, and a production build. Browser smoke tests are separate because they require an installed Playwright browser.

## Deferred work

- SITE-0003: external canonical-corpus discovery and ingestion
- SITE-0004: document metadata schemas and registry
- SITE-0005: complete page trees and information architecture
- SITE-0006: final visual system
- SITE-0007: technical MDX component library
