import { loader } from 'fumadocs-core/source';
import { defineDocs } from 'fumadocs-mdx/macro';

const systemDocs = defineDocs({
  dir: 'content/system',
});

export const systemSource = loader({
  baseUrl: '/system',
  source: systemDocs.toFumadocsSource(),
});
