# Monad Publication Site Development

**Work packet:** SITE-0002 of 12

## Requirements

- Bun 1.3.14 or newer within the 1.3 release line
- Node.js 22 or newer for tools that invoke Node directly

## First install

```bash
cp .env.example .env.local
bun install
bun run verify
```

## Daily workflow

```bash
bun run dev
```

Before committing site changes:

```bash
bun run verify
```

For the complete browser check:

```bash
bun run test:e2e:install # first machine setup only
bun run verify:full
```

## Command contract

| Command | Purpose |
|---|---|
| `bun run check` | Biome formatting and lint checks |
| `bun run typecheck` | Strict TypeScript validation |
| `bun run test:unit` | Fast configuration and contract tests |
| `bun run build` | Production Next.js and Fumadocs build |
| `bun run test:e2e` | Chromium smoke tests |
| `bun run verify` | Required local and CI quality gate |
| `bun run verify:full` | Quality gate plus browser tests |

## Environment contract

`NEXT_PUBLIC_SITE_URL` must be an absolute URL. `NEXT_PUBLIC_REPOSITORY_URL` is optional and is omitted from navigation when blank. Invalid values fail during application evaluation rather than silently producing malformed metadata.

## Generated data

The following directories are disposable and ignored by Git:

- `.next/`
- `.source/`
- `coverage/`
- `playwright-report/`
- `test-results/`

Remove them with:

```bash
bun run clean
```
