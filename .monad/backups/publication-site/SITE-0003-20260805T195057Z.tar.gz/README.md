# Monad Engineering Log Site

The presentation application for Monad's documentation, engineering journal, and derived publications.

**Current work packet:** SITE-0002 of 12

## Start locally

```bash
cp .env.example .env.local
bun install
bun run dev
```

Open `http://localhost:3000`.

## Validate

```bash
bun run verify
```

See [`DEVELOPMENT.md`](./DEVELOPMENT.md) for the complete command and testing contract, and [`ARCHITECTURE.md`](./ARCHITECTURE.md) for repository boundaries and route ownership.

The files under `content/system/` remain bootstrap fixtures. SITE-0003 will introduce the canonical repository-content ingestion adapter.
