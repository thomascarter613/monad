import { createFromSource } from 'fumadocs-core/search/server';
import { systemSource } from '@/lib/source';

export const { GET } = createFromSource(systemSource);
